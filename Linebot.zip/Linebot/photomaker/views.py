# from django.shortcuts import render

# Create your views here.
from django.conf import settings
from django.http import HttpResponse, HttpResponseBadRequest, HttpResponseForbidden
from django.views.decorators.csrf import csrf_exempt

from linebot import LineBotApi, WebhookParser
from linebot.exceptions import InvalidSignatureError, LineBotApiError
from linebot.models import MessageEvent,TextSendMessage

from module import func1,func2,func3

import re

# 在callback函数中，根据用户输入的文本提取出需要搜索的电影名称
def extract_movie_name(text):
    # 正則表示式模式，提取 "#" 後面的文字
    pattern = r"#(.*)"
    match = re.search(pattern, text)
    if match:
        # 返回提取到的電影名稱
        return match.group(1).strip()  # 去除首尾空格
    else:
        return None  # 如果沒有匹配到，則返回None

line_bot_api = LineBotApi(settings.LINE_CHANNEL_ACCESS_TOKEN)
parser = WebhookParser(settings.LINE_CHANNEL_SECRET)

 
@csrf_exempt
def callback(request):
    
    if request.method == 'POST':
        signature = request.META['HTTP_X_LINE_SIGNATURE']
        body = request.body.decode('utf-8')
 
        try:
            events = parser.parse(body, signature)  # 傳入的事件
        except InvalidSignatureError:
            return HttpResponseForbidden()
        except LineBotApiError:
            return HttpResponseBadRequest()
        
        line_bot_api = LineBotApi('Wxd/n4BNp6Lj+Zv9JQdN63QyELrUCo5UoAu5lGBsT9dMo+sACMxL76MuEQTcX9ZMdEB7F4++gjS4Dt3GGc6Tf/o2ZzutsJfgsZU9ysgIFMq4sM1TSrVqr5vJ0JifRhat5OC6KUdeod+GsfUDnXGJVAdB04t89/1O/w1cDnyilFU=')
        for event in events:
            if isinstance(event, MessageEvent):  # 如果有訊息事件
                #第一個選項Start
                if event.message.text == '本週強檔':
                    line_bot_api.reply_message(event.reply_token, TextSendMessage(text='「本週強檔」執行中請稍後....'))
                    func1.Line_reply(line_bot_api, event)
                #第一個選項End
                
                #第二個選項Start
                elif event.message.text == '隨機推薦':
                    line_bot_api.reply_message(event.reply_token, TextSendMessage(text='「隨機推薦」執行中請稍後....'))
                    func2.Line_reply(line_bot_api, event)
                # 第二個選項End
                #第三個選項Start
                elif event.message.text.startswith("#"):
                    Name = extract_movie_name(event.message.text)
                    line_bot_api.reply_message(event.reply_token, TextSendMessage(text='搜尋中請稍後....'))
                    moviedict = func3.searchMovie(Name)
                    func3.Line_reply(line_bot_api, event, moviedict)
                # 第三個選項End

                
        return HttpResponse()
    else:
        return HttpResponseBadRequest()


    
def some_view(request):
    response = HttpResponse()
    response['Connection'] = 'keep-alive'
    response['Keep-Alive'] = 'timeout=5000,max=9999'
    return response
