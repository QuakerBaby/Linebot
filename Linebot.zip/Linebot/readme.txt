【執行】

1.先cd到LineBot資料夾底下

2.
pip install Django
pip install line-bot-sdk

3.
#初始化資料庫遷移
python manage.py makemigrations
python manage.py migrate

4.
#開啟Django內建伺服器指令
python manage.py runserver

5.
開啟ngrok.exe，cd到LineBot資料夾底下

6.
用ngrok http 8000開啟
更改LINE API
