from bs4 import BeautifulSoup

from selenium import webdriver
from selenium.webdriver.common.by import By
from time import sleep

from linebot.models import FlexSendMessage,TextSendMessage


def searchMovie(Name):
    global driver
    moviedict={"src":[],"duration":[],"img_src":[],"title":[],"release_date":[],"story":[],"url":[]}
    driver = webdriver.Chrome() # PhantomJs
    driver.implicitly_wait(5)
    driver.get("https://www.vscinemas.com.tw/vsweb/film/index.aspx") 
    page_number = 2  # 初始化頁碼
    while True:
       try:
           driver.find_element(By.PARTIAL_LINK_TEXT, Name).click()
           sleep(1)
           break
           
       except:
           try:
               driver.find_element(By.CSS_SELECTOR,f'a[href="?p={page_number}"]')
           except:
               driver.quit()  # 這裡添加退出瀏覽器的操作
               return None
           driver.find_element(By.CSS_SELECTOR,f'a[href="?p={page_number}"]').click()
           page_number += 1
           sleep(1)


    soup = BeautifulSoup(driver.page_source, 'html.parser')
    
    #開始找資料
    #找url
    current_url = driver.current_url
    moviedict["url"].append(current_url)
    
    #找YT連結
    iframe_tag = soup.find('iframe', attrs={'u': 'image'})

    # 如果找到了指定的<iframe>标签
    if iframe_tag:
        # 获取<iframe>标签的src属性值
        src = iframe_tag.get('src')
        moviedict["src"].append(src)
    else:
        print("找不到指定的<iframe>标签")
        
        
    # 找片長
    td_tag = soup.find('td', string='片長：')
    if td_tag:
        duration = td_tag.find_next_sibling('td').get_text(strip=True)
        moviedict["duration"].append(duration)
    else:
        print("找不到指定的<td>标签")
        
        
    # 找到特定的<div>標籤(片名、圖片、上片時間)
    movie_main = soup.find('div', class_='movieMain')
    if movie_main:
        # 找到<img>標籤並提取src和title屬性
        img_tag = movie_main.find('img')
        img_src = img_tag['src'] if img_tag else 'N/A'
        img_title = img_tag['title'] if img_tag else 'N/A'

        # 找到<time>標籤並提取上映日期
        time_tag = movie_main.find('time')
        release_date = time_tag.text.strip() if time_tag else 'N/A'

        moviedict["img_src"].append("https://www.vscinemas.com.tw/vsweb/"+img_src[3:])
        moviedict["title"].append(img_title)
        moviedict["release_date"].append(release_date[5:])
        
    else:
        print("找不到指定的<div>標籤")
        
    #找簡介    
    story_tag = soup.find('div', class_='bbsArticle')
    
    # 如果找到了<div class="bbsArticle">标签
    if story_tag:
        # 获取<p>标签的内容
        p_tags = story_tag.find_all('p')
        for p_tag in p_tags:
            story=p_tag.get_text()
            moviedict["story"].append(story)
    else:
        print("找不到指定的<div class=\"bbsArticle\">标签")
        
        
    driver.quit()
    
    return  moviedict
#LINEBOT回覆程式--------------------------------------------------------------------------------------------------------------------------------
def Line_reply(line_bot_api, event,moviedict):    
    moviedicts = moviedict
    if moviedicts is None:
        line_bot_api.push_message(event.source.user_id, TextSendMessage(text='未找到相關電影'))
    else:
        flex_message = {
          "type": "bubble",
          "hero": {
            "type": "image",
            "url":moviedicts["img_src"][0] ,
            "size": "full",
            "aspectRatio": "20:13",
            "aspectMode": "cover",
            "action": {
              "type": "uri",
              "uri": "https://line.me/"
            }
          },
          "body": {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": moviedicts["title"][0] ,
                "weight": "bold",
                "size": "xl"
              },
              {
                "type": "box",
                "layout": "vertical",
                "margin": "lg",
                "spacing": "sm",
                "contents": [
                  {
                    "type": "box",
                    "layout": "baseline",
                    "spacing": "sm",
                    "contents": [
                      {
                        "type": "text",
                        "color": "#aaaaaa",
                        "size": "md",
                        "flex": 2,
                        "weight": "regular",
                        "style": "normal",
                        "wrap": True,
                        "offsetTop": "none",
                        "offsetBottom": "none",
                        "offsetStart": "none",
                        "offsetEnd": "none",
                        "text": "上映日期",
                        "position": "relative"
                      },
                      {
                        "type": "text",
                        "text": moviedicts["release_date"][0],
                        "color": "#666666",
                        "size": "md",
                        "flex": 5,
                        "wrap": True
                      }
                    ]
                  },
                  {
                    "type": "box",
                    "layout": "baseline",
                    "spacing": "sm",
                    "contents": [
                      {
                        "type": "text",
                        "color": "#aaaaaa",
                        "size": "md",
                        "flex": 2,
                        "weight": "regular",
                        "style": "normal",
                        "wrap": True,
                        "offsetTop": "none",
                        "offsetBottom": "none",
                        "offsetStart": "none",
                        "offsetEnd": "none",
                        "text": "片長",
                        "position": "relative"
                      },
                      {
                        "type": "text",
                        "text": moviedicts["duration"][0],
                        "color": "#666666",
                        "size": "md",
                        "flex": 5,
                        "wrap": True
                      }
                    ]
                  },
                  {
                    "type": "box",
                    "layout": "baseline",
                    "spacing": "sm",
                    "contents": [
                      {
                        "type": "text",
                        "text": "劇情簡介",
                        "color": "#aaaaaa",
                        "size": "md",
                        "flex": 2,
                        "wrap": True
                      },
                      {
                        "type": "text",
                        "text": moviedicts["story"][0],
                        "wrap": True,
                        "color": "#666666",
                        "size": "md",
                        "flex": 5
                      }
                    ]
                  }
                ]
              }
            ],
            "backgroundColor": "#fffaf0"
          },
          "footer": {
            "type": "box",
            "layout": "vertical",
            "spacing": "sm",
            "contents": [
              {
                "type": "button",
                "style": "link",
                "height": "sm",
                "action": {
                  "type": "uri",
                  "label": "宣傳片",
                  "uri": moviedicts["src"][0]
                }
              },
              {
                "type": "button",
                "style": "link",
                "height": "sm",
                "action": {
                  "type": "uri",
                  "label": "買票去!",
                  "uri":  moviedicts["url"][0]
                }
              },
              {
                "type": "button",
                "style": "link",
                "height": "sm",
                "action": {
                  "type": "uri",
                  "label": "加入最愛",
                  "uri": "https://www.vscinemas.com.tw/vsweb/film/detail.aspx?id=7159"
                }
              },
            ],
            "flex": 0,
            "backgroundColor": "#fffaf0"
          },
          "styles": {
            "footer": {
              "separator": True
            }
          }
        }
    
        
        # 創建 FlexSendMessage 物件
        flex_send_message = FlexSendMessage(alt_text="This is a Flex Message", contents=flex_message)
        
        # 傳送 Flex Message
        line_bot_api.push_message(event.source.user_id, flex_send_message)

