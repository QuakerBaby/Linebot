# -*- coding: utf-8 -*-
"""
Created on Fri May 10 09:02:58 2024

@author: USER
"""
from linebot.models import TextSendMessage, TemplateSendMessage, CarouselTemplate, CarouselColumn, MessageAction, URIAction

import requests
from bs4 import BeautifulSoup

import json


#爬蟲程式--------------------------------------------------------------------------------------------------------------------------------
def top5():
    headers = {"User-Agent": "Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148"}
    r = requests.get('https://www.vscinemas.com.tw/vsweb/film/index.aspx', headers=headers)
    sp = BeautifulSoup(r.text, 'lxml')
    top5dict = {'title': [], 'img_src': [], 'detail_link': [], "advertising_video": []}
    
    figures = sp.find_all('figure')
    
    for figure in figures:
        mark_tag = figure.find('mark')
        if mark_tag:
            if mark_tag.text.strip() == "票房冠軍" or mark_tag.text.strip() == "票房前五":
                img_tag = figure.find('img')
                a_tag = figure.find('a')
                title = img_tag["title"]
                img_src = 'https://www.vscinemas.com.tw/vsweb/' + img_tag["src"][3:]
                detail_link = "https://www.vscinemas.com.tw/vsweb/film/" + a_tag["href"]
                
                top5dict['title'].append(title)
                top5dict['img_src'].append(img_src)
                top5dict['detail_link'].append(detail_link)
                
                r_advertising_video = requests.get(detail_link, headers=headers)
                sp_advertising_video = BeautifulSoup(r_advertising_video.text, 'lxml')
                divs = sp_advertising_video.select('div.movieVideo iframe[src]')
                if divs:
                    iframe_tag = divs[0]
                    advertising_video = iframe_tag["src"]
                    top5dict['advertising_video'].append(advertising_video)

    return(top5dict)


#爬票房程式--------------------------------------------------------------------------------------------------------------------------------
def tickets_num():
    headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0"}
    r = requests.get('https://boxofficetw.tfai.org.tw/home/tfw?domestic=false&_=1714821554405',headers=headers)
    sp = BeautifulSoup(r.text, 'lxml')#有lxml和html5lib兩種
    # soup = BeautifulSoup(sp, "html.parser")
    json_str = sp.find("p").text
    data = json.loads(json_str)
    tickets_num=[]
    top5_data=top5()
    
    for movie_title in top5_data['title']:
        for film in data["data"]["topFilms"]:
            if film["name"]==movie_title:
                amounts = film["amounts"]
        tickets_num.append(format(int(amounts), ",d"))
    return(tickets_num)

#LINEBOT回覆程式--------------------------------------------------------------------------------------------------------------------------------
def Line_reply(line_bot_api, event):
    top5_data=top5()
    tickets_num_data=tickets_num()
    line_bot_api.push_message(event.source.user_id, TextSendMessage(text='以下是當紅電影推薦'))
    line_bot_api.push_message(event.source.user_id, TemplateSendMessage(
        alt_text='CarouselTemplate',
        template=CarouselTemplate(
                columns=[
                    #start
                    CarouselColumn(
                        thumbnail_image_url=top5_data["img_src"][0],
                        title=top5_data["title"][0],
                        text='熱門電影TOP1',
                        actions=[
                            MessageAction(
                                label='票房資訊',
                                text="【"+top5_data["title"][0]+'】的票房:'+tickets_num_data[0]
                            ),
                            URIAction(
                                label='觀看預告片',
                                uri=top5_data["advertising_video"][0]
                            ),
                            URIAction(
                                label='前往購票',
                                uri=top5_data["detail_link"][0]
                            )
                        ]
                    ),
                    #end
                    #start
                    CarouselColumn(
                        thumbnail_image_url=top5_data["img_src"][1],
                        title=top5_data["title"][1],
                        text='熱門電影TOP2',
                        actions=[
                            MessageAction(
                                label='票房資訊',
                                text="【"+top5_data["title"][1]+'】的票房:'+tickets_num_data[1]
                            ),
                            URIAction(
                                label='觀看預告片',
                                uri=top5_data["advertising_video"][1]
                            ),
                            URIAction(
                                label='前往購票',
                                uri=top5_data["detail_link"][1]
                            )
                        ]
                    ),
                    #end
                    #start
                    CarouselColumn(
                        thumbnail_image_url=top5_data["img_src"][2],
                        title=top5_data["title"][2],
                        text='熱門電影TOP3',
                        actions=[
                            MessageAction(
                                label='票房資訊',
                                text="【"+top5_data["title"][2]+'】的票房:'+tickets_num_data[2]
                            ),
                            URIAction(
                                label='觀看預告片',
                                uri=top5_data["advertising_video"][2]
                            ),
                            URIAction(
                                label='前往購票',
                                uri=top5_data["detail_link"][2]
                            )
                        ]
                    ),
                    #end
                    #start
                    CarouselColumn(
                        thumbnail_image_url=top5_data["img_src"][3],
                        title=top5_data["title"][3],
                        text='熱門電影TOP4',
                        actions=[
                            MessageAction(
                                label='票房資訊',
                                text="【"+top5_data["title"][3]+'】的票房:'+tickets_num_data[3]
                            ),
                            URIAction(
                                label='觀看預告片',
                                uri=top5_data["advertising_video"][3]
                            ),
                            URIAction(
                                label='前往購票',
                                uri=top5_data["detail_link"][3]
                            )
                        ]
                    ),
                    #end
                    #start
                    CarouselColumn(
                        thumbnail_image_url=top5_data["img_src"][4],
                        title=top5_data["title"][4],
                        text='熱門電影TOP5',
                        actions=[
                            MessageAction(
                                label='票房資訊',
                                text="【"+top5_data["title"][4]+'】的票房:'+tickets_num_data[4]
                            ),
                            URIAction(
                                label='觀看預告片',
                                uri=top5_data["advertising_video"][4]
                            ),
                            URIAction(
                                label='前往購票',
                                uri=top5_data["detail_link"][4]
                            )
                        ]
                    ),
                    #end
            ]
        )
    ))
