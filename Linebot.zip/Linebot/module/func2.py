import requests
from bs4 import BeautifulSoup
import numpy as np

from linebot.models import TextSendMessage,URIAction,TemplateSendMessage,ImageCarouselTemplate, ImageCarouselColumn

#爬蟲程式--------------------------------------------------------------------------------------------------------------------------------
def fetch_page(url, headers):
    try:
        response = requests.get(url, headers=headers, timeout=10)
        if response.status_code == 200:
            return response.text
    except Exception as e:
        print(f"Error fetching {url}: {e}")
    return None
#爬蟲程式--------------------------------------------------------------------------------------------------------------------------------
def extract_movie_info(splist):
    titlelist = []
    for sp in splist:
        uls = sp.find_all('ul', class_='movieList')
        for figure in uls:
            img_tags = figure.find_all("img")  # 使用 find_all 获取所有 img 标签
            for img_tag in img_tags:  # 遍历所有 img 标签
                title = img_tag.get("title")  # 使用 get 方法获取标题
                if title:
                    titlelist.append(title)
    return titlelist
#爬蟲程式--------------------------------------------------------------------------------------------------------------------------------
def ran_movie():

    headers = {"User-Agent": "Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148"}
    base_url = 'https://www.vscinemas.com.tw/vsweb/film/index.aspx'
    splist = []
    
    for page in range(1, 6):
        url = f'{base_url}?p={page}'
        page_content = fetch_page(url, headers)
        if not page_content:
            break
        sp = BeautifulSoup(page_content, 'lxml')
        splist.append(sp)
    
    titlelist = extract_movie_info(splist)
    titlelist = np.random.choice(titlelist, 3, replace=False)
    
    ran_dict = {'title': [], 'img_src': [], 'detail_link': [], "advertising_video": []}
    
    for title in titlelist:
        for sp in splist:
            img_tags = sp.find_all("img", alt=title)  # 找到所有匹配標题的 img 標籤
            for img_tag in img_tags:
                parent_a_tag = img_tag.find_parent("a")  # 找到包含 img 標籤的父级 a 標籤
                if parent_a_tag:
                    ran_dict["detail_link"].append("https://www.vscinemas.com.tw/vsweb/film/"+parent_a_tag["href"])  # 获取父级 a 标签的 href 属性
                    ran_dict["title"].append(title)
                    ran_dict["img_src"].append("https://www.vscinemas.com.tw/vsweb/" + img_tag["src"][3:])
    
    for detail_link in ran_dict["detail_link"]:
        page_content = fetch_page(detail_link, headers)
        if page_content:
            sp = BeautifulSoup(page_content, 'lxml')
            divs = sp.find_all('div', class_="mainVideo")
            if divs:
                iframe_tag = divs[0].find("iframe")
                if iframe_tag:
                    ran_dict["advertising_video"].append(iframe_tag["src"])
            else:
                ran_dict["advertising_video"].append(detail_link)
    return(ran_dict)

#LINEBOT回覆程式--------------------------------------------------------------------------------------------------------------------------------
def Line_reply(line_bot_api, event):       
    random_movie_urls=ran_movie()#隨機電影的預告片
    line_bot_api.push_message(event.source.user_id, TextSendMessage(text='以下是隨機三部電影推薦'))
    line_bot_api.push_message(event.source.user_id, TemplateSendMessage(
        alt_text='ImageCarousel template',
        template=ImageCarouselTemplate(
            columns=[
                ImageCarouselColumn(
                    image_url=random_movie_urls["img_src"][0], 
                    action=URIAction(
                        label=random_movie_urls["title"][0][:12],
                        uri=random_movie_urls["advertising_video"][0]
                        )
                    ),
                ImageCarouselColumn(
                    image_url=random_movie_urls["img_src"][1], 
                    action=URIAction(
                        label=random_movie_urls["title"][1][:12],
                        uri=random_movie_urls["advertising_video"][1]
                        )
                    ),
                ImageCarouselColumn(
                    image_url=random_movie_urls["img_src"][2], 
                    action=URIAction(
                        label=random_movie_urls["title"][2][:12],
                        uri=random_movie_urls["advertising_video"][2]
                        )
                    ),
            ]
        )
    ))
    line_bot_api.push_message(event.source.user_id, TextSendMessage(text='如果喜歡推薦的影片，想進一步了解電影資訊，可以輸入「#電影名稱」來進行搜尋'))
    


